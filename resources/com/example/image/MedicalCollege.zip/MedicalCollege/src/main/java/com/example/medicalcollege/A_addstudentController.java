package com.example.medicalcollege;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import com.example.medicalcollege.DatabaseController;

public class A_addstudentController {
    @FXML
    private TextField addbirthdate;

    @FXML
    private TextField addemail;

    @FXML
    private TextField addid;

    @FXML
    private TextField addname;

    @FXML
    private TextField addpassword;

    @FXML
    private VBox contactLayout;

    @FXML
    void createstudentaccount(ActionEvent event) {
        String name = addname.getText();
        String pss = addpassword.getText();
        String email = addemail.getText();
        String  id= addid.getText();
        String  birthdate= addbirthdate.getText();
        try {
            Connection databaselink = new DatabaseController().getConnection();
            String query = "insert into student(S_Name, S_Id,Mail,Date_of_birth,Password) values(?,?,?,?,?)";
            PreparedStatement pat = databaselink.prepareStatement(query);
            pat.setString(1, name);
            pat.setString(2, id);
            pat.setString(3, email);
            pat.setString(4, birthdate);
            pat.setString(5, pss);

            pat.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
